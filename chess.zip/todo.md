## stuff not to forget to do:

- en passant

- promotion

- drag pieces!!

- show available spaces!!